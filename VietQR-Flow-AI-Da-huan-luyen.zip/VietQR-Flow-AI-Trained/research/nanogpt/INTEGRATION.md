Nguồn: https://github.com/karpathy/nanoGPT
Commit: 3adf61e154c3fe3fca428ad6bc3818b27a3b8291

Giữ nguyên mã upstream và MIT license. Đây là mã nghiên cứu Python/PyTorch, chưa tích hợp runtime vào WebView. Chưa có checkpoint được huấn luyện/đánh giá cho trích xuất chuyển khoản tiếng Việt. Không gọi mã này từ app và không tuyên bố kết quả hiện tại là nanoGPT. Cần mô hình, tokenizer, dữ liệu đánh giá và runtime tương thích Android trước khi bật. Bộ tách hiện tại vẫn là public/local-extract.mjs.


1.5.0: Đã huấn luyện thực tế bộ phân loại vai trò khoản tiền dùng GPT transformer từ model.py, thêm classification head 3 lớp. Mã training/amount-model/train.py, checkpoint và báo cáo được giữ kèm. Trọng số Float32 tại public/assets/amount-model; runtime JavaScript tương đương chạy trong worker. Không phải mô hình sinh ngôn ngữ hay ChatGPT; không học xác minh tài khoản. Chỉ gợi ý số tiền có trích nguồn, không tự áp dụng khi nguồn có nhiều khoản.
