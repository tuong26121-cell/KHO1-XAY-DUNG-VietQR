import {AmountClassifier} from './amount-runtime.mjs';
import {amountCandidates,candidateTokens,selectAmount} from './amount-features.mjs';
let model;
async function load(){
 if(model)return model;
 const [meta,response]=await Promise.all([fetch('/assets/amount-model/model.json'),fetch('/assets/amount-model/weights.bin')]);
 if(!meta.ok||!response.ok)throw new Error('Chưa tải được mô hình.');
 const manifest=await meta.json(),buffer=await response.arrayBuffer();
 const digest=await crypto.subtle.digest('SHA-256',buffer),hash=Array.from(new Uint8Array(digest),x=>x.toString(16).padStart(2,'0')).join('');
 if(hash!==manifest.sha256)throw new Error('Tệp mô hình chưa khớp kiểm tra.');
 return model=new AmountClassifier(manifest,buffer);
}
self.onmessage=async({data})=>{
 try{
  const classifier=await load(),text=String(data.text).normalize('NFC'),candidates=amountCandidates(text);
  if(candidates.length>6)throw new Error('Có quá nhiều khoản tiền để tự chọn.');
  const predictions=candidates.map((_,i)=>classifier.predict(candidateTokens(text,candidates,i)));
  self.postMessage({id:data.id,candidateCount:candidates.length,selected:selectAmount(candidates,predictions,classifier.m.threshold),predictions,model:'Flow nanoGPT Amount 1'});
 }catch(error){self.postMessage({id:data.id,error:error.message});}
};
