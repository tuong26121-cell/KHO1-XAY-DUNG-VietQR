// Inference for the trained nanoGPT transformer + 3-class amount-role head.
// All weights come from this project's documented synthetic training run.
export class AmountClassifier {
 constructor(manifest,buffer){
  if(manifest.format!=='nanoGPT-amount-classifier-f32-v1')throw new Error('Định dạng mô hình chưa hỗ trợ.');
  this.m=manifest;this.stoi=new Map(manifest.vocab.map((v,i)=>[v,i]));this.w={};
  for(const [name,spec] of Object.entries(manifest.weights)){
   const size=spec.shape.reduce((a,b)=>a*b,1);
   if(spec.offset<0||(spec.offset+size)*4>buffer.byteLength)throw new Error('Mô hình bị thiếu dữ liệu.');
   this.w[name]=new Float32Array(buffer,spec.offset*4,size);
  }
 }
 tokens(text){return text.normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/g,'d').replace(/Đ/g,'D').toLowerCase().match(/[a-z]+|[.!?:;,]/g)||[];}
 predict(tokens){
  const {n_embd:C,block_size:T,n_head:H,n_layer:L}=this.m.config;
  if(tokens.length>T)throw new Error('Đoạn hội thoại dài hơn phạm vi mô hình.');
  if(tokens.filter(t=>!this.stoi.has(t)).length/Math.max(1,tokens.length)>0.25)throw new Error('Có nhiều từ ngoài phạm vi mô hình. Hãy nhập theo nhãn rõ ràng.');
  const ids=Array(T-tokens.length).fill(0).concat(tokens.map(t=>this.stoi.get(t)??1));
  const w=this.w;let x=new Float32Array(T*C);
  for(let t=0;t<T;t++)for(let c=0;c<C;c++)x[t*C+c]=w['gpt.transformer.wte.weight'][ids[t]*C+c]+w['gpt.transformer.wpe.weight'][t*C+c];
  for(let l=0;l<L;l++){
   const p=`gpt.transformer.h.${l}`;
   const norm=layerNorm(x,w[p+'.ln_1.weight'],w[p+'.ln_1.bias'],T,C);
   const qkv=linear(norm,w[p+'.attn.c_attn.weight'],w[p+'.attn.c_attn.bias'],T,C,3*C);
   const att=new Float32Array(T*C),D=C/H,scale=1/Math.sqrt(D);
   for(let h=0;h<H;h++)for(let t=0;t<T;t++){
    const scores=new Float64Array(t+1);let max=-Infinity;
    for(let s=0;s<=t;s++){let a=0;for(let d=0;d<D;d++)a+=qkv[t*3*C+h*D+d]*qkv[s*3*C+C+h*D+d];scores[s]=a*scale;max=Math.max(max,scores[s]);}
    let total=0;for(let s=0;s<=t;s++){scores[s]=Math.exp(scores[s]-max);total+=scores[s];}
    for(let d=0;d<D;d++){let v=0;for(let s=0;s<=t;s++)v+=scores[s]/total*qkv[s*3*C+2*C+h*D+d];att[t*C+h*D+d]=v;}
   }
   const a=linear(att,w[p+'.attn.c_proj.weight'],w[p+'.attn.c_proj.bias'],T,C,C);
   for(let i=0;i<x.length;i++)x[i]+=a[i];
   const n=layerNorm(x,w[p+'.ln_2.weight'],w[p+'.ln_2.bias'],T,C);
   const f=linear(n,w[p+'.mlp.c_fc.weight'],w[p+'.mlp.c_fc.bias'],T,C,4*C);
   for(let i=0;i<f.length;i++)f[i]=0.5*f[i]*(1+erf(f[i]/Math.SQRT2));
   const b=linear(f,w[p+'.mlp.c_proj.weight'],w[p+'.mlp.c_proj.bias'],T,4*C,C);
   for(let i=0;i<x.length;i++)x[i]+=b[i];
  }
  x=layerNorm(x,w['gpt.transformer.ln_f.weight'],w['gpt.transformer.ln_f.bias'],T,C);
  const logits=linear(x.subarray((T-1)*C),w['head.weight'],w['head.bias'],1,C,3);
  const max=Math.max(...logits),exp=Array.from(logits,v=>Math.exp(v-max)),sum=exp.reduce((a,b)=>a+b,0);
  return exp.map(v=>v/sum);
 }
}
function linear(x,w,b,T,I,O){const y=new Float32Array(T*O);for(let t=0;t<T;t++)for(let o=0;o<O;o++){let s=b?.[o]||0;for(let i=0;i<I;i++)s+=x[t*I+i]*w[o*I+i];y[t*O+o]=s;}return y;}
function layerNorm(x,w,b,T,C){const y=new Float32Array(x.length);for(let t=0;t<T;t++){let mean=0,v=0;for(let c=0;c<C;c++)mean+=x[t*C+c];mean/=C;for(let c=0;c<C;c++)v+=(x[t*C+c]-mean)**2;const inv=1/Math.sqrt(v/C+1e-5);for(let c=0;c<C;c++)y[t*C+c]=(x[t*C+c]-mean)*inv*w[c]+b[c];}return y;}
function erf(x){const sign=x<0?-1:1,a=Math.abs(x),t=1/(1+0.3275911*a);return sign*(1-(((((1.061405429*t-1.453152027)*t)+1.421413741)*t-0.284496736)*t+0.254829592)*t*Math.exp(-a*a));}
