export const APP_VERSION = '1.5.0';
export const MAX_AMOUNT = 499999999n;

export function fold(value) {
  return String(value).normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/đ/g, 'd').replace(/Đ/g, 'D');
}

export function amountValue(input) {
  const value = String(input ?? '').trim().replace(/\s*(?:vnd|vnđ|đ|dong|đồng)\s*$/i, '').trim();
  if (!value) return '';
  const suffix = fold(value).match(/^([0-9]+(?:[.,][0-9]{1,6})?)\s*(k|nghin|ngan|tr|trieu)$/i);
  let result;
  if (suffix) {
    const parts = suffix[1].replace(',', '.').split('.');
    const multiplier = /^(k|nghin|ngan)$/i.test(suffix[2]) ? 1000n : 1000000n;
    const fraction = parts[1] || '';
    const divisor = 10n ** BigInt(fraction.length);
    const numerator = BigInt(parts[0] + fraction) * multiplier;
    if (numerator % divisor !== 0n) throw new Error('Số tiền phải là số nguyên đồng.');
    result = numerator / divisor;
  } else {
    if (!/^(?:[0-9]+|[1-9][0-9]{0,2}(?:\.[0-9]{3})+|[1-9][0-9]{0,2}(?:,[0-9]{3})+)$/.test(value)) {
      throw new Error('Nhập số nguyên đồng, ví dụ 250000 hoặc 250.000.');
    }
    result = BigInt(value.replace(/[.,]/g, ''));
  }
  if (result < 1n || result > MAX_AMOUNT) throw new Error('Số tiền từ 1 đến 499.999.999 đồng, hoặc để trống.');
  return result.toString();
}

export function validateTransfer(value, banks) {
  const data = {
    bank: String(value.bank || ''),
    account: String(value.account || '').trim(),
    name: String(value.name || '').trim(),
    amount: '',
    memo: String(value.memo || '').trim(),
  };
  const errors = {};
  if (!banks.some(bank => bank.bin === data.bank && bank.transferSupported === 1)) errors.bank = 'Chọn ngân hàng nhận tiền trong danh sách.';
  if (!/^[0-9]{6,19}$/.test(data.account)) errors.account = 'Số tài khoản cần có 6–19 chữ số. Hãy đối chiếu cả số 0 ở đầu.';
  if (data.name.length > 70 || /[\r\n\x00-\x1f]/.test(data.name)) errors.name = 'Tên hiển thị tối đa 70 ký tự, trên một dòng.';
  try { data.amount = amountValue(value.amount); } catch (error) { errors.amount = error.message; }
  if (data.memo.length > 25 || !/^[A-Za-z0-9 .\/-]*$/.test(data.memo)) errors.memo = 'Dùng tối đa 25 ký tự không dấu: chữ, số, khoảng trắng, . / -';
  return { data, errors, valid: Object.keys(errors).length === 0 };
}

export function crc16(input) {
  let crc = 0xffff;
  for (const byte of new TextEncoder().encode(input)) {
    crc ^= byte << 8;
    for (let i = 0; i < 8; i++) crc = (crc & 0x8000) ? ((crc << 1) ^ 0x1021) & 0xffff : (crc << 1) & 0xffff;
  }
  return crc.toString(16).toUpperCase().padStart(4, '0');
}

export function tlv(tag, value) {
  const length = new TextEncoder().encode(value).length;
  if (!/^\d{2}$/.test(tag) || length > 99 || /[^\x20-\x7e]/.test(value)) throw new Error('Dữ liệu mã QR vượt giới hạn định dạng.');
  return `${tag}${String(length).padStart(2, '0')}${value}`;
}

export function buildVietQR(data) {
  if (!/^\d{6}$/.test(data.bank) || !/^\d{6,19}$/.test(data.account)) throw new Error('Ngân hàng hoặc số tài khoản không hợp lệ.');
  if (data.amount && (!/^\d+$/.test(data.amount) || amountValue(data.amount) !== data.amount)) throw new Error('Số tiền chưa hợp lệ.');
  if (data.memo.length > 25 || !/^[A-Za-z0-9 .\/-]*$/.test(data.memo)) throw new Error('Nội dung chuyển khoản chưa hợp lệ.');
  const destination = tlv('00', data.bank) + tlv('01', data.account);
  const merchant = tlv('00', 'A000000727') + tlv('01', destination) + tlv('02', 'QRIBFTTA');
  const payload = tlv('00', '01') + tlv('01', data.amount ? '12' : '11') + tlv('38', merchant) + tlv('53', '704') +
    (data.amount ? tlv('54', data.amount) : '') + tlv('58', 'VN') + (data.memo ? tlv('62', tlv('08', data.memo)) : '') + '6304';
  return payload + crc16(payload);
}

function parseTLV(input) {
  const result = {};
  let offset = 0;
  while (offset < input.length) {
    const tag = input.slice(offset, offset + 2), lengthText = input.slice(offset + 2, offset + 4);
    if (!/^\d{2}$/.test(tag) || !/^\d{2}$/.test(lengthText) || Object.hasOwn(result, tag)) throw new Error('Trường QR không hợp lệ hoặc bị lặp.');
    const length = Number(lengthText);
    if (offset + 4 + length > input.length) throw new Error('Dữ liệu QR bị thiếu.');
    result[tag] = input.slice(offset + 4, offset + 4 + length);
    offset += 4 + length;
  }
  return result;
}

export function readVietQR(payload) {
  if (!/^[\x20-\x7e]+$/.test(payload) || !/6304[0-9A-F]{4}$/.test(payload) || crc16(payload.slice(0, -4)) !== payload.slice(-4)) throw new Error('Mã không có CRC VietQR hợp lệ.');
  const fields = parseTLV(payload), merchant = parseTLV(fields['38'] || ''), destination = parseTLV(merchant['01'] || '');
  if (fields['00'] !== '01' || !['11', '12'].includes(fields['01']) || fields['53'] !== '704' || fields['58'] !== 'VN' || merchant['00'] !== 'A000000727' || merchant['02'] !== 'QRIBFTTA') throw new Error('Đây không phải QR chuyển khoản đến tài khoản được hỗ trợ.');
  return { bank: destination['00'] || '', account: destination['01'] || '', amount: fields['54'] || '', memo: fields['62'] ? parseTLV(fields['62'])['08'] || '' : '', name: '' };
}

function sourceLines(text) {
  // Speech recognition and pasted messages often have no line breaks.
  // Segment by explicit field labels while preserving the original text.
  const labels = 'ten chu tai khoan|chu tai khoan|ten nguoi nhan|nguoi nhan|ten tai khoan|chu tk|account name|so tai khoan|tai khoan|so tk|stk|account no|ngan hang|so tien(?: can chuyen)?|amount|noi dung(?: chuyen khoan)?|loi nhan|description|memo|nd';
  const marker = new RegExp(`(^|[\\s;,]+)(${labels})(?:[ \\t]*(?:[:#=]|-(?=[ \\t]))[ \\t]*|[ \\t]+)`, 'gi');
  const normalized = fold(text), entries = [];
  let inMemo = false;
  for (const match of normalized.matchAll(marker)) {
    // Words such as "người nhận" inside a memo are content, not new fields.
    if (inMemo && !/[\n;,]/.test(match[1])) continue;
    entries.push({ start: match.index + match[1].length, boundary: match.index });
    inMemo = /^(?:noi dung|loi nhan|description|memo|nd)/i.test(match[2]);
  }
  if (!entries.length) return text.split(/\r?\n/).map(line => line.trim()).filter(Boolean);
  const result = [];
  const prefix = text.slice(0, entries[0].boundary).trim();
  if (prefix) result.push(prefix);
  entries.forEach((entry, index) => {
    const value = text.slice(entry.start, entries[index + 1]?.boundary ?? text.length).trim();
    if (value) result.push(...value.split(/\r?\n/).map(line => line.trim()).filter(Boolean));
  });
  return result;
}

function labeledValue(lines, labels) {
  const values = [];
  const pattern = new RegExp(`(?:^|[;,]\\s*)(?:${labels})[ \\t]*(?:[:#=]|-(?=[ \\t]))?[ \\t]*([^\\s:#=].*)$`, 'i');
  for (const line of lines) {
    const match = fold(line).match(pattern);
    if (match) values.push(line.slice(match.index + match[0].length - match[1].length).trim());
  }
  return values;
}

export function parseSource(input, banks) {
  const text = String(input).normalize('NFC').trim();
  const lines = sourceLines(text);
  const warnings = [];
  const result = { bank: '', account: '', name: '', amount: '', memo: '' };
  const normalized = ' ' + fold(text).toLowerCase() + ' ';
  const aliases = { '970436': ['vcb', 'vietcombank'], '970422': ['mbbank', 'mb bank', 'mb'], '970415': ['vietinbank', 'ctg', 'icb'], '970418': ['bidv'], '970405': ['agribank', 'vba'], '970407': ['techcombank', 'tcb'], '970416': ['acb'], '970423': ['tpbank', 'tp bank'], '970432': ['vpbank', 'vp bank'], '970403': ['sacombank', 'stb'], '970452': ['kienlongbank', 'kien long bank', 'kien long', 'klb'] };
  const bankHits = banks.filter(bank => {
    const names = [...new Set([bank.shortName, bank.code, bank.bin, ...(aliases[bank.bin] || [])])].map(fold).map(s => s.toLowerCase());
    return names.some(name => {
      const escaped = name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      return new RegExp(`(^|[^a-z0-9])${escaped}($|[^a-z0-9])`).test(normalized);
    });
  });
  if (bankHits.length === 1) result.bank = bankHits[0].bin;
  if (bankHits.length > 1) warnings.push('Nguồn nhắc nhiều ngân hàng. Hãy chọn đúng ngân hàng nhận.');
  const accounts = labeledValue(lines, 'so tai khoan|tai khoan|so tk|stk|account(?: no)?').map(v => v.split(/[;,]/)[0].replace(/[ \t]/g, '')).filter(Boolean);
  if (new Set(accounts).size === 1) result.account = accounts[0];
  else if (accounts.length > 1) warnings.push('Có nhiều số tài khoản. Hãy chọn và nhập tài khoản nhận.');
  if (!accounts.length) {
    const unlabelled = lines.filter(line => !/^(?:ngan hang|so tai khoan|tai khoan|so tk|stk|account|chu tai khoan|ten chu tai khoan|nguoi nhan|ten nguoi nhan|ten tai khoan|chu tk|so tien|amount|chuyen|noi dung|nd|loi nhan|description|memo)(?:\s|[:#=\-]|$)/i.test(fold(line)))
      .filter(line => !/(?:vnd|vnđ|đồng|dong|trieu|triệu|nghin|nghìn|ngan|ngàn|[0-9]\s*k\b)/i.test(line)).join('\n');
    const candidates = [...unlabelled.matchAll(/(?<![\w.])\d{6,19}(?![\w.])/g)].map(m => m[0]).filter(v => !banks.some(b => b.bin === v));
    if (new Set(candidates).size === 1) { result.account = candidates[0]; warnings.push('Số tài khoản được tìm từ dãy số chưa có nhãn. Cần đối chiếu lại nguồn.'); }
    else if (candidates.length) warnings.push('Có nhiều dãy số chưa có nhãn; chưa tự chọn số tài khoản.');
  }
  const names = labeledValue(lines, 'chu tai khoan|ten chu tai khoan|nguoi nhan|ten nguoi nhan|ten tai khoan|chu tk|account name');
  if (names.length === 1) result.name = names[0];
  else if (names.length > 1) warnings.push('Nguồn có nhiều tên người nhận. Hãy đối chiếu và nhập tên cần hiển thị.');
  const amounts = labeledValue(lines, 'so tien(?: can chuyen)?|amount|chuyen').map(v => v.split(/[;]/)[0]);
  if (amounts.length === 1) { try { result.amount = amountValue(amounts[0]); } catch(error) { warnings.push('Số tiền trong nguồn chưa rõ: ' + error.message); } }
  else if (amounts.length > 1) warnings.push('Nguồn có nhiều số tiền. Hãy nhập số tiền cần chuyển.');
  const memos = labeledValue(lines, 'noi dung(?: chuyen khoan)?|nd|loi nhan|description|memo');
  if (memos.length === 1) result.memo = memos[0];
  else if (memos.length > 1) warnings.push('Nguồn có nhiều nội dung chuyển khoản. Hãy chọn nội dung cần dùng.');
  const found = Object.keys(result).filter(key => result[key] !== '');
  if (!result.bank) warnings.push('Chưa xác định được ngân hàng nhận.');
  if (!result.account) warnings.push('Chưa xác định được số tài khoản nhận.');
  return { data: result, warnings, found };
}
