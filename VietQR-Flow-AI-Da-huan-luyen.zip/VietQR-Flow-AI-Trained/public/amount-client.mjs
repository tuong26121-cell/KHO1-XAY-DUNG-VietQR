let worker,sequence=0;
const pending=new Map();
function shutdown(){for(const job of pending.values())job.reject(new Error('Chưa chạy được mô hình trên thiết bị.'));pending.clear();worker?.terminate();worker=null;}
export function analyzeMoney(text,{signal}={}){
 return new Promise((resolve,reject)=>{
  if(signal?.aborted){reject(new DOMException('Đã hủy','AbortError'));return;}
  try{
   if(!worker){
    worker=new Worker('/amount-worker.mjs',{type:'module'});
    worker.onmessage=({data})=>{const job=pending.get(data.id);if(!job)return;pending.delete(data.id);data.error?job.reject(new Error(data.error)):job.resolve(data);};
    worker.onerror=shutdown;
   }
   const id=++sequence;
   const finish=(fn,value)=>{clearTimeout(timer);signal?.removeEventListener('abort',abort);fn(value);};
   const abort=()=>{pending.delete(id);finish(reject,new DOMException('Đã hủy','AbortError'));};
   const timer=setTimeout(()=>{pending.delete(id);finish(reject,new Error('Phân tích vượt thời gian chờ. Bạn vẫn có thể nhập tay.'));},12000);
   pending.set(id,{resolve:value=>finish(resolve,value),reject:error=>finish(reject,error)});
   signal?.addEventListener('abort',abort,{once:true});worker.postMessage({id,text});
  }catch(error){reject(error);}
 });
}
