import {fold,amountValue} from './core.mjs';
export function amountCandidates(input){
 const text=String(input).normalize('NFC'),source=fold(text).toLowerCase();
 const pattern=/(?<![\w.,−-])\d+(?:[.,]\d+)*\s*(?:trieu|nghin|ngan|tr|k|vnd|dong|đ)(?![a-z])/g;
 const matches=[...source.matchAll(pattern)].map(m=>({start:m.index,end:m.index+m[0].length}));
 for(const match of source.matchAll(/\b(?:so tien|amount)\s*[:=]\s*(\d+(?:[.,]\d+)*)/g)){
  const start=match.index+match[0].lastIndexOf(match[1]),end=start+match[1].length;
  if(!matches.some(c=>start<c.end&&end>c.start))matches.push({start,end});
 }
 return matches.sort((a,b)=>a.start-b.start).map(c=>{
  const quote=text.slice(c.start,c.end);let value='';try{value=amountValue(quote);}catch{}
  const before=source.slice(Math.max(0,c.start-35),c.start);
  if(/(?:khoang|tam|du kien|uoc luong|chua chot|am|[-−])\s*$/.test(before))value='';
  return {...c,quote,value};
 });
}
export function candidateTokens(text,candidates,target){
 // NFC keeps the offsets aligned with the folded Vietnamese source.
 let masked='',cursor=0;
 for(let i=0;i<candidates.length;i++){const c=candidates[i];masked+=text.slice(cursor,c.start)+(i===target?' focus ':' money ');cursor=c.end;}
 masked+=text.slice(cursor);
 const normalized=fold(masked).toLowerCase(),clauses=normalized.split(/[.!?;\n]/);
 const clause=clauses.find(c=>/\bfocus\b/.test(c))||normalized;
 return (clause.match(/[a-z]+|[.!?:;,]/g)||[]).concat('cls');
}
export function selectAmount(candidates,predictions,threshold=0.995){
 if(candidates.length!==predictions.length||!candidates.length)return null;
 // Exactly one confident transfer and every alternative confidently irrelevant.
 const chosen=predictions.map((p,i)=>p[1]>=threshold?i:-1).filter(i=>i>=0);
 if(chosen.length!==1)return null;const at=chosen[0];
 if(!candidates[at].value||predictions.some((p,i)=>i!==at&&p[0]<threshold))return null;
 return {...candidates[at],confidence:predictions[at][1]};
}
