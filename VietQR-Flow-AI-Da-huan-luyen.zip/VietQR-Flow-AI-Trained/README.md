# VietQR Flow 1.5.0

Bản này giữ chức năng QR, OCR và ngân hàng của 1.4.0; bổ sung mô hình AI đã huấn luyện thực tế trên máy để phân loại vai trò khoản tiền.

## AI trên thiết bị

- Transformer dựa trên `research/nanogpt/model.py` (giữ MIT license), thêm đầu phân loại 3 lớp: khoản khác / khoản chuyển / chưa chốt.
- Huấn luyện từ khởi tạo ngẫu nhiên, 12.000 mẫu tổng hợp, 905 đầu vào phân loại khác nhau sau xử lý, 16 vòng. Không dùng tài khoản hoặc hội thoại thật, không dùng mô hình OpenAI/API.
- Trọng số khoảng 252 KiB, runtime JavaScript chạy trong Web Worker. Ảnh vẫn dùng OCR Tesseract; ngân hàng/tài khoản vẫn được tách theo quy tắc.
- Kiểm tra độc lập 597 trường hợp tổng hợp từ mẫu câu giữ riêng (113 đầu vào phân loại khác nhau), không trùng đầu vào training; kết quả chỉ phản ánh bộ thử hẹp này. Xem `training/amount-model/evaluation.json`, gồm cả 18 ca viết tay và các trường hợp từ chối.
- Không phải ChatGPT; chưa đánh giá bằng dữ liệu người dùng thật. Chưa hiểu đầy đủ câu chuyện, nhiều người nhận, khoản tiền bằng chữ hoặc ngôn ngữ lạ. Từ lạ, câu quá dài hoặc thiếu chắc chắn có thể phải nhập tay.
- Mô hình chỉ đề xuất một giá trị có trong nguồn. Khi có nhiều khoản, cần bấm Dùng số tiền gợi ý hoặc nhập tay; không tự thay số tiền bằng kết quả mô hình. Mọi thay đổi làm hết hiệu lực QR cũ.
- Không thay đổi quyền riêng tư website hoặc cấu hình OpenAI cũ; giao diện không gọi OpenAI.

## Huấn luyện và tái lập

Cài Python 3.12, `torch==2.6.0` CPU và numpy; chạy `python3 training/amount-model/train.py`. Script tạo dữ liệu tổng hợp, huấn luyện nanoGPT transformer và đầu phân loại, chọn checkpoint theo validation loss, xuất Float32 cùng SHA-256, dự đoán PyTorch làm mẫu so sánh JavaScript, checkpoint và báo cáo. Bộ validation chung cấu trúc training; đánh giá mẫu câu giữ riêng nằm trong evaluation.json. Không diễn giải điểm validation hoặc test tổng hợp là độ chính xác thực tế.

Giữ mã, checkpoint, dữ liệu, log và báo cáo trong `training/amount-model`. Kiểm thử `npm test` bao gồm so sánh runtime JavaScript/PyTorch, worker, sự thay đổi nguồn và nút áp dụng gợi ý. Mô hình và đầu vào chỉ xử lý ở thiết bị.

## Trạng thái xác minh

Kiểm thử Node và biên dịch website/APK, chữ ký và dữ liệu đóng gói. Chưa kiểm tra trên trình duyệt/điện thoại thật. Đăng nhập, xác thực và xác nhận chuyển tiền vẫn do app ngân hàng xử lý; không lưu mật khẩu.

## Luồng sử dụng

Scan ảnh bằng Tesseract tại thiết bị → xem/sửa văn bản → chủ động tách thông tin trên thiết bị → kiểm tra các trường → xác nhận → tạo, giải mã kiểm tra và xuất QR.

Sau khi scan, bộ tách và mô hình phân tích nguồn để đề xuất trường chuyển khoản. Có thể sửa văn bản, sao chép hoặc tải TXT. Không gửi văn bản tới OpenAI và không cần khóa API. Kết quả là đề xuất; không xác minh chủ tài khoản hoặc thực hiện chuyển tiền.

Tách thông tin miễn phí theo nhãn rõ ràng, ngân hàng và số tiền có đơn vị. Nhiều số tiền hoặc số tiền dự kiến để trống cho người dùng chọn. Không phải ChatGPT và không hiểu đầy đủ câu chuyện. Nút Xóa tất cả dọn nội dung đang tạo, giữ lịch sử/tài khoản đã lưu.

QR chỉ lấy dữ liệu từ bảng **Kết quả chuyển khoản** sau khi người dùng xác nhận. Có thể sửa trực tiếp bảng này dù nguồn phía trên còn nội dung khác. Sửa nguồn không thay kết quả hiện tại; bấm điền thông tin hoặc áp dụng đề xuất mới thay bảng. Sửa bảng kết quả sẽ bỏ xác nhận và khóa QR cũ cho đến khi tạo lại.

Có thể dán chuỗi VietQR vào nguồn để kiểm CRC và giải mã, hoặc xem/sao chép chuỗi của QR vừa tạo trong Chi tiết kiểm tra mã. Sau khi tạo mã, nút **Mở ứng dụng ngân hàng** cho chọn app của người chuyển. Các app có hỗ trợ điền sẵn nhận dữ liệu từ đúng QR đã xác nhận qua liên kết công khai VietQR.io. App khác chỉ được mở; tải QR rồi chọn Quét QR → Ảnh đã lưu trong app. Không mặc định app người chuyển là ngân hàng người nhận. Giao dịch cần được người dùng kiểm tra và xác nhận trong app ngân hàng.

## Thành phần

- `app/flow-shell.html`: giao diện hiện có; hai route `/` và `/index.html` phục vụ cùng giao diện.
- `public/`: mã trình duyệt, thư viện OCR/QR, mô hình, phông chữ và hình ảnh.
- `public/payment.mjs`: kiểm tra lại QR đã xác nhận và tạo liên kết mở app ngân hàng.
- `public/assets/bank-apps.json`: danh sách liên kết Android/iOS từ API công khai VietQR.io, chụp ngày 24/10/2026.
- `public/local-extract.mjs`: bộ tách thông tin hiện dùng, hoàn toàn trên thiết bị.
- `server/openai.mjs` (giữ lại, giao diện không gọi): OpenAI Responses API, Structured Outputs, kiểm tra dữ liệu đề xuất, đồng ý gửi dữ liệu, giới hạn đầu vào và lỗi dịch vụ.
- `app/api/ai/status`: chỉ trả trạng thái cấu hình và tên mô hình.
- `app/api/ai/extract`: xử lý văn bản qua OpenAI; mặc định GPT-6.1 Sol, reasoning low, giới hạn đầu ra, store=false, không dùng tools hoặc tự thử lại.
- Backend dùng Vinext và Sites Worker starter. Bí mật do Sites cung cấp tại runtime, không được nhúng trong mã trình duyệt hay manifest. `.env.local` và tham chiếu `.dev.vars` chỉ phục vụ phát triển, không theo dõi trong Git.

Website hiện là owner-private và dựa vào Sites dispatch để bảo vệ mọi yêu cầu từ người xem và service access. Cần bổ sung quyền truy cập cho API trước khi chuyển sang đối tượng rộng hơn. Giới hạn 10 yêu cầu/phút là giới hạn trong từng runtime, không phải trần chi tiêu API cho toàn tài khoản.

## Trạng thái API cũ (không dùng trong giao diện 1.5.0)

Đã tạo khóa riêng và cấu hình bí mật OPENAI_API_KEY. Lần kiểm tra trực tiếp OpenAI trả HTTP 429, code credit_balance_exhausted, type insufficient_quota. Tài khoản cần bổ sung số dư API nếu muốn sử dụng lại dịch vụ OpenAI cũ. Mô hình trên thiết bị của 1.5.0 không phụ thuộc số dư này. Không tự nạp tiền hoặc đổi sang nhà cung cấp khác. Phí API thuộc tài khoản OpenAI và tách với gói ChatGPT.

## Chạy và kiểm tra

Mã nguồn đầy đủ gồm giao diện, mã QR/OCR, backend OpenAI, thư viện và mô hình cục bộ, tệp khóa phụ thuộc và kiểm thử. Khóa API riêng không nằm trong gói mã nguồn.

Với Node.js từ 22.13.0, giải nén rồi chạy `npm ci` và `npm run dev`. Chạy kiểm thử bằng `npm test`, build bằng `npm run build`. Chế độ scan/OCR, điền thủ công và tạo QR không cần khóa OpenAI. Khi tự chạy phần ChatGPT, đặt OPENAI_API_KEY ở phía máy chủ theo môi trường chạy; không đưa khóa vào public/ hoặc HTML.

Trên môi trường Sites, dùng Sites skill để cài phụ thuộc, mở preview, build, đóng gói và triển khai. Preview quản lý: `sites-preview start /workspace/sites/vietqr-flow-studio`. Không đưa các tệp môi trường hoặc dữ liệu runtime vào mã nguồn.

## Giới hạn còn lại

Chưa kiểm tra một đề xuất thực từ OpenAI do tài khoản chưa có số dư API. Các ca thành công của lớp tích hợp dùng phản hồi nhà cung cấp giả lập trong kiểm thử. Chưa mở liên kết hoặc quét QR bằng ứng dụng ngân hàng, thử micro hoặc WebShare/PWA trên điện thoại thật. Việc mở/điền sẵn tùy phiên bản app và dịch vụ điều hướng. OCR chữ viết tay/ảnh mờ không được bảo đảm. Tên người nhận chỉ hiển thị ngoài QR; người dùng luôn đối chiếu với ứng dụng ngân hàng.

Các thư viện OCR/QR và giấy phép nằm trong `public/vendor/`. Nguồn ngân hàng: VietQR.io, ảnh chụp danh sách 23/10/2026. Biểu tượng ứng dụng lấy từ ảnh người dùng; minh họa khối kính xanh tạo bằng image_gen trong phiên làm việc này.
