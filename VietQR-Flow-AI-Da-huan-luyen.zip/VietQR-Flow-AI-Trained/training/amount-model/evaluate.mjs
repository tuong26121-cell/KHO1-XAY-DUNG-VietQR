// Reproduce the held-out-template benchmark using the deployed JS runtime.
import {readFileSync,writeFileSync} from 'node:fs';
import {AmountClassifier} from '../../public/amount-runtime.mjs';
import {amountCandidates,candidateTokens,selectAmount} from '../../public/amount-features.mjs';
const dir=new URL('./',import.meta.url),assets=new URL('../../public/assets/amount-model/',import.meta.url);
const meta=JSON.parse(readFileSync(new URL('model.json',assets))),bytes=readFileSync(new URL('weights.bin',assets));
const model=new AmountClassifier(meta,bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength));
const lines=name=>readFileSync(new URL(name,dir),'utf8').trim().split('\n').map(JSON.parse);
const train=lines('train.jsonl'),test=lines('test.jsonl').filter(r=>r.target===0);
const seen=new Set(train.map(r=>JSON.stringify(r.tokens)));let correct=0,abstain=0,overlap=0;
for(const r of test){
 if(seen.has(JSON.stringify(r.tokens)))overlap++;
 try{const p=model.predict(r.tokens);if(p.indexOf(Math.max(...p))===r.label)correct++;}catch{abstain++;}
}
const old=JSON.parse(readFileSync(new URL('evaluation.json',dir)));
const handwrittenCases=old.handwrittenCases.map(({text,expected})=>{
 let selected=null,error;
 try{const c=amountCandidates(text),p=c.map((_,i)=>model.predict(candidateTokens(text,c,i)));selected=selectAmount(c,p)?.value??null;}catch(e){error=e.message;}
 return {text,expected,selected,pass:selected===expected,...(error?{abstention:error}:{})};
});
if(overlap)throw new Error('Training/test input overlap');
const report={heldOutTemplateExamples:test.length,uniqueHeldOutInputs:new Set(test.map(r=>JSON.stringify(r.tokens))).size,trainInputOverlap:overlap,correct,abstain,accuracy:correct/test.length,handwrittenCases,handwrittenPass:handwrittenCases.filter(r=>r.pass).length,note:old.note};
writeFileSync(new URL('evaluation.json',dir),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({heldOut:report.heldOutTemplateExamples,unique:report.uniqueHeldOutInputs,accuracy:report.accuracy,handwrittenPass:report.handwrittenPass}));
