"""Train a small nanoGPT-backed amount-role classifier on synthetic Vietnamese.
No pretrained weights, external account data, or paid services are used.
Run with torch==2.6.0+cpu and numpy. Export is Float32 for the JS runtime.
"""
from pathlib import Path
import sys, re, json, random, unicodedata, hashlib, time, copy
import numpy as np
import torch
from torch import nn

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'research/nanogpt'))
from model import GPT,GPTConfig

SEED=261024
random.seed(SEED);np.random.seed(SEED);torch.manual_seed(SEED)
torch.set_num_threads(4)
OUT=ROOT/'public/assets/amount-model';OUT.mkdir(parents=True,exist_ok=True)
DATA=Path(__file__).resolve().parent
def fold(s):return ''.join(c for c in unicodedata.normalize('NFD',s.lower().replace('đ','d')) if unicodedata.category(c)!='Mn')
def words(s):return re.findall(r'[a-z]+|[.!?:;,]',fold(s))

# Labels: 0=other (balance, fees, old/negated), 1=transfer, 2=not settled.
# Each clause has exactly one annotated amount; all numbers are masked before learning.
TRAIN=[
 ('Chuyển cho {n} {m} nhé',1),('Gửi {m} vào tài khoản của {n}',1),
 ('Số tiền: {m}',1),('Chốt chuyển {m} cho {n}',1),('Thanh toán {m} cho {n}',1),
 ('Tiền cần chuyển là {m}',1),('Mình đồng ý gửi {m}',1),('Trả cho {n} {m}',1),
 ('Chuyển khoản {m} đến {n}',1),('Số tiền cuối cùng là {m}',1),('Bạn chuyển đúng {m}',1),
 ('Số dư hiện có {m}',0),('Phí dịch vụ là {m}',0),('Đã chuyển {m} hôm qua',0),
 ('Lúc trước nói {m} nhưng hủy rồi',0),('Không chuyển {m}',0),('Tiền trong ví {m}',0),
 ('Đơn hàng cũ {m} đã thanh toán',0),('Đừng gửi {m}',0),('Khoản {m} là phí ngân hàng',0),
 ('Dự kiến gửi khoảng {m}',2),('Có lẽ chuyển {m}',2),('Tạm tính {m} chưa chốt',2),
 ('Định chuyển {m} nhưng chưa chắc',2),('Ước lượng {m}',2),('Sẽ bàn lại số tiền {m}',2),
 ('Chưa quyết định có gửi {m} hay không',2),('Khoảng {m} được không',2),
]
DEVELOPMENT=[
 ('Nhờ bạn chuyển giúp {n} số tiền {m}',1),('Chốt số tiền cần gửi: {m}',1),
 ('Số dư tài khoản là {m}',0),('Không gửi khoản {m} này',0),
 ('Số tiền dự kiến khoảng {m} vẫn chưa chốt',2),('Tạm tính khoản {m}',2),
]
TRAIN+=DEVELOPMENT+[
 ('Không gửi {m}',0),('Không chuyển khoản {m}',0),('Chuyển {m} là khoản đã trả',0),
 ('Khoản {m} không cần gửi nữa',0),('Phí chuyển tiền: {m}',0),('Phí giao dịch {m}',0),
 ('Số dư tài khoản còn {m}',0),('Số dư còn lại {m}',0),('Trong tài khoản đang có {m}',0),
 ('Khoản {m} đã trả xong',0),('Tiền phí là {m}',0),('Hôm trước đã gửi {m}',0),
 ('Cần thanh toán tổng cộng {m}',1),('Bạn chuyển {m} giúp mình nhé',1),
 ('Đồng ý chuyển cho {n} {m}',1),('Đồng ý trả {n} {m}',1),('Gửi đúng {m} cho {n}',1),
 ('Tổng số tiền cần gửi: {m}',1),('Nhờ bạn thanh toán {m}',1),('Chốt lại trả {m}',1),
 ('Khoản {m} chỉ là dự kiến',2),('Mức dự kiến là {m}',2),('Đang cân nhắc {m}',2),
 ('Khoản {m} chưa được chốt',2),('Chưa chốt có thể là {m}',2),('Số tiền tạm tính là {m}',2),
 ('Khoản {m} vẫn cần bàn lại',2),('Chưa xác định chính xác có phải {m}',2),
]
HELDOUT=[
 ('Số dư còn lại trong tài khoản: {m}',0),('Khoản phí chuyển tiền: {m}',0),
 ('Khoản {m} đã trả xong hôm trước',0),('Bạn chuyển {m} giúp mình',1),
 ('Cần thanh toán cho {n} tổng số {m}',1),('Đồng ý trả {n} đúng {m}',1),
 ('Mức {m} chỉ là dự kiến',2),('Khoản {m} vẫn đang cân nhắc',2),('Chưa chốt, có thể là {m}',2),
]
def local_tokens(s):
 clauses=re.split(r'[.!?;\n]',s)
 clause=next((c for c in clauses if re.search(r'\bfocus\b',c)),s)
 return words(clause)+['cls']
names=['An','Bình','Châu','Dũng','Hà','Linh','Minh','Nam','Tường','Vy']
prefixes=['','Bạn ơi. ','A: Xin chào. B: ','Mình nhắn lại nhé. ','Thông tin hôm nay. ']
suffixes=['',' Cảm ơn bạn.',' Ngân hàng Techcombank. STK 0012345678.',' Nội dung: TRA TIEN.',' Làm xong báo mình.']
def dataset(count,seed,heldout=False,excluded=None):
 rng=random.Random(seed);rows=[];seen=set();excluded=excluded or set()
 while len(rows)<count:
  clauses=[];labels=[];frames=[]
  n=rng.choice(names)
  size=rng.choice([1,2,2,3,3,4])
  for i in range(size):
   pool=HELDOUT if heldout and i==0 else TRAIN
   frame,label=rng.choice(pool);clauses.append(frame.format(n=n,m=f'[{i}]'));labels.append(label);frames.append(frame)
  order=list(range(size));rng.shuffle(order)
  skeleton=rng.choice(prefixes)+'. '.join(clauses[i] for i in order)+rng.choice(suffixes)
  key=fold(re.sub(r'\[\d+\]', '[money]', skeleton))
  if key in seen or key in excluded:continue
  seen.add(key)
  for target in range(size):
   processed=skeleton
   for i in range(size):processed=processed.replace(f'[{i}]','focus' if i==target else 'money')
   tokens=local_tokens(processed)
   if len(tokens)>64:continue
   amounts=[rng.choice(['15.000 VND','250k','1,5 triệu','120000 đồng','75 nghìn']) for _ in range(size)]
   raw=skeleton
   for i,a in enumerate(amounts):raw=raw.replace(f'[{i}]',a)
   rows.append({'text':raw,'skeleton':skeleton,'target':target,'label':labels[target],'tokens':tokens,'frames':frames})
 return rows[:count],seen

train,seen=dataset(12000,SEED)
valid,vseen=dataset(1500,SEED+1,excluded=seen)
test,tseen=dataset(1500,SEED+2,heldout=True,excluded=seen|vseen)
assert not seen&vseen and not seen&tseen and not vseen&tseen
vocab=['pad','unk']+sorted(set(w for r in train for w in r['tokens'])-{'pad','unk'})
stoi={w:i for i,w in enumerate(vocab)}
def encode(rows):
 x=torch.zeros((len(rows),64),dtype=torch.long)
 for i,r in enumerate(rows):
  ids=[stoi.get(t,1) for t in r['tokens']];x[i,-len(ids):]=torch.tensor(ids)
 return x,torch.tensor([r['label'] for r in rows])
for name,rows in [('train',train),('validation',valid),('test',test)]:
 (DATA/(name+'.jsonl')).write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows))
X,Y=encode(train);VX,VY=encode(valid);TX,TY=encode(test)
cfg=GPTConfig(block_size=64,vocab_size=len(vocab),n_layer=2,n_head=2,n_embd=48,dropout=0.05,bias=True)
class Classifier(nn.Module):
 def __init__(self):
  super().__init__();self.gpt=GPT(cfg);self.head=nn.Linear(cfg.n_embd,3)
 def forward(self,x):
  t=self.gpt.transformer
  h=t.drop(t.wte(x)+t.wpe(torch.arange(x.shape[1])))
  for block in t.h:h=block(h)
  return self.head(t.ln_f(h)[:,-1])
model=Classifier();opt=torch.optim.AdamW(model.parameters(),lr=0.0015,weight_decay=0.01)
@torch.no_grad()
def evaluate(x,y):
 model.eval();logits=torch.cat([model(x[i:i+128]) for i in range(0,len(x),128)])
 return float(nn.functional.cross_entropy(logits,y)),float((logits.argmax(-1)==y).float().mean()),logits
best=float('inf');beststate=None;logs=[];start=time.time()
for epoch in range(16):
 model.train();order=torch.randperm(len(X));losses=[]
 for i in range(0,len(X),96):
  idx=order[i:i+96];loss=nn.functional.cross_entropy(model(X[idx]),Y[idx]);opt.zero_grad();loss.backward();nn.utils.clip_grad_norm_(model.parameters(),1);opt.step();losses.append(loss.item())
 vl,va,_=evaluate(VX,VY)
 if vl<best:best=vl;beststate=copy.deepcopy(model.state_dict())
 entry={'epoch':epoch+1,'trainLoss':sum(losses)/len(losses),'validationLoss':vl,'validationAccuracy':va,'elapsedSeconds':round(time.time()-start,1)};logs.append(entry);print(json.dumps(entry),flush=True)
model.load_state_dict(beststate);model.eval()
vl,va,_=evaluate(VX,VY);tl,ta,logits=evaluate(TX,TY)
probs=logits.softmax(-1);prediction=probs.argmax(-1);conf=probs.max(-1).values;gate=conf>=0.995
cm=torch.zeros((3,3),dtype=torch.int64)
for a,b in zip(TY.tolist(),prediction.tolist()):cm[a,b]+=1
state=model.state_dict();weights={};chunks=[];offset=0
for name,value in state.items():
 if name=='gpt.lm_head.weight':continue
 arr=value.detach().cpu().contiguous().numpy().astype('<f4');weights[name]={'offset':offset,'shape':list(arr.shape)};chunks.append(arr.tobytes());offset+=arr.size
blob=b''.join(chunks);(OUT/'weights.bin').write_bytes(blob)
manifest={'format':'nanoGPT-amount-classifier-f32-v1','version':'1','config':{k:getattr(cfg,k) for k in ['block_size','n_layer','n_head','n_embd','vocab_size']},'vocab':vocab,'weights':weights,'sha256':hashlib.sha256(blob).hexdigest(),'classes':['other','transfer','unsettled'],'threshold':0.995,'training':'synthetic Vietnamese amount-role classification; not a general chatbot'}
(OUT/'model.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
torch.save({'state_dict':state,'manifest':manifest},DATA/'checkpoint.pt')
gold=[]
for i in range(min(40,len(test))):gold.append({'tokens':test[i]['tokens'],'probabilities':probs[i].tolist()})
(DATA/'parity.json').write_text(json.dumps(gold,ensure_ascii=False,indent=2)+'\n')
report={'seed':SEED,'sourceModelSha256':hashlib.sha256((ROOT/'research/nanogpt/model.py').read_bytes()).hexdigest(),'trainingExamples':len(train),'uniqueProcessedTrainingInputs':len({tuple(r['tokens']) for r in train}),'validationExamples':len(valid),'testExamples':len(test),'uniqueConversationSkeletons':{'train':len(seen),'validation':len(vseen),'test':len(tseen)},'split':'disjoint conversation skeletons; final test includes held-out clause templates; prior development test used for augmentation','data':'synthetic only; no real-user benchmark','parameters':sum(p.numel() for p in model.parameters()),'epochs':16,'validationAccuracy':va,'testAccuracy':ta,'confusionMatrixActualByPredicted':cm.tolist(),'highConfidenceCoverage':float(gate.float().mean()),'highConfidenceAccuracy':float((prediction[gate]==TY[gate]).float().mean()) if gate.any() else None,'elapsedSeconds':round(time.time()-start,1),'logs':logs,'sha256':manifest['sha256']}
(DATA/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
